package mutiplyAddComplex;

import java.util.Scanner;

/*
 * ʵ�����ۼ�
 * @author chencheng
 * @Date 2017.3.26
 */
public class MutiplyAddComplex {
	static int real1;
	static int real2;
	static int img1;
	static int img2;
	public static void main(String[] args) {
		Component con1,con2;
		Complex com1,com2;
		com1=new Complex(real1,img1);
		com2=new Complex(real2,img2);
		con1=new Formation();
		con2=new Formation();
		con1.add(com1);
		con2.add(com2);
		con1.AddComplex(con2);
		
		
	}
	 public int getReal1() {
 		return real1;
 	}

 	public void setReal1(int real1) {
 		this.real1 = real1;
 	}

 	public int getImg1() {
 		return img1;
 	}

 	public void setImg1(int img1) {
 		this.img1 = img1;
 	}
     
 
	
}

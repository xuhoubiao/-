package mutiplyAddComplex;
/*
 * ʵ�ֹ��ɸ������ࡪ������Ҷ��
 * @author chencheng
 * @Date 2017.2.25
 */
public class Complex extends Component{
	public Complex(int newReal, int newImage) {
		// TODO Auto-generated constructor stub
	}
	public void add(Component con){
		
	}
	public void AddComplex(Component con){ 
	        int newReal = con.getReal1() + con.getReal2();  
	        int newImage = con.getImg1() + con.getImg2();  
	        Complex result = new Complex(newReal,newImage); 
	        return;
	}      
	
	
}
